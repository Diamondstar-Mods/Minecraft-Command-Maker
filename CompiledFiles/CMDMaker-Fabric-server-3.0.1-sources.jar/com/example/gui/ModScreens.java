package com.example.gui;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ModScreens {
    public static final class_3917<FunctionChestHandler> FUNCTION_CHEST =
        new class_3917<FunctionChestHandler>(FunctionChestHandler::new, net.minecraft.class_7699.method_45397());

    public static void register() {
        class_2378.method_10230(class_7923.field_41187,
            class_2960.method_60655("nekkycommandmaker", "function_chest"),
            FUNCTION_CHEST);
    }
}
