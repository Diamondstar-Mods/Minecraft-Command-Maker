package com.example.gui;

import com.example.FunctionManager;
import com.example.AliasManager;
import java.nio.file.*;
import java.util.*;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_9334;

public class FunctionChestHandler extends class_1703 {
    public static final int ROWS = 6;
    public static final int COLS = 9;
    public static final int CONTAINER_SIZE = ROWS * COLS;

    private final class_1277 inventory;
    private final class_1657 player;
    private int currentTab = 0;
    private int currentPage = 0;
    private Map<String, String> manifest = new LinkedHashMap<>();
    private List<String> localFunctions = new ArrayList<>();

    public FunctionChestHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, null);
    }

    public FunctionChestHandler(int syncId, class_1661 playerInventory, class_3917<?> type) {
        super(type != null ? type : ModScreens.FUNCTION_CHEST, syncId);
        this.player = playerInventory.field_7546;
        this.inventory = new class_1277(CONTAINER_SIZE);

        for (int i = 0; i < CONTAINER_SIZE; i++) {
            int row = i / COLS;
            int col = i % COLS;
            this.method_7621(new LockedSlot(inventory, i, 8 + col * 18, 18 + row * 18));
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 198));
        }

        loadAndRefresh();
    }

    private void loadAndRefresh() {
        new Thread(() -> {
            manifest = FunctionManager.fetchFunctionManifest();
            localFunctions = FunctionManager.listLocalFunctions();
            refreshDisplay();
        }).start();
    }

    private void refreshDisplay() {
        inventory.method_5448();
        drawTabs();
        drawContent();
        drawNavigation();
    }

    private void drawTabs() {
        inventory.method_5447(0, makeItem(currentTab == 0 ? class_1802.field_8581 : class_1802.field_8656, "§a§lDownload"));
        inventory.method_5447(1, makeItem(currentTab == 1 ? class_1802.field_8196 : class_1802.field_8747, "§b§lMy Functions"));
        inventory.method_5447(2, makeItem(currentTab == 2 ? class_1802.field_8703 : class_1802.field_8761, "§e§lCreate New"));
        for (int i = 3; i < 8; i++) {
            inventory.method_5447(i, makeItem(class_1802.field_8157, " "));
        }
        inventory.method_5447(8, makeItem(class_1802.field_8557, "§6§lRefresh"));
    }

    private void drawContent() {
        int slotStart = COLS;
        int contentSlots = COLS * 4;
        List<FunctionEntry> entries = getCurrentEntries();
        int startIdx = currentPage * contentSlots;

        for (int i = 0; i < contentSlots; i++) {
            int slotIdx = slotStart + i;
            int entryIdx = startIdx + i;
            if (entryIdx < entries.size()) {
                inventory.method_5447(slotIdx, entries.get(entryIdx).toItemStack());
            }
        }
    }

    private List<FunctionEntry> getCurrentEntries() {
        List<FunctionEntry> entries = new ArrayList<>();
        switch (currentTab) {
            case 0 -> {
                for (Map.Entry<String, String> e : manifest.entrySet()) {
                    if (!localFunctions.contains(e.getKey())) {
                        entries.add(new FunctionEntry(e.getKey(), EntryType.DOWNLOAD));
                    }
                }
            }
            case 1 -> {
                List<String> sorted = new ArrayList<>(localFunctions);
                Collections.sort(sorted);
                for (String name : sorted) {
                    entries.add(new FunctionEntry(name, EntryType.LOCAL));
                }
            }
            case 2 -> {
                entries.add(new FunctionEntry("Empty Function", EntryType.CREATE_EMPTY));
                entries.add(new FunctionEntry("Command Template", EntryType.CREATE_CMD));
                entries.add(new FunctionEntry("Mob Spawner", EntryType.CREATE_MOB));
                entries.add(new FunctionEntry("Building", EntryType.CREATE_BUILD));
            }
        }
        return entries;
    }

    private void drawNavigation() {
        int total = getCurrentEntries().size();
        int contentSlots = COLS * 4;
        int maxPage = Math.max(0, (total - 1) / contentSlots);
        inventory.method_5447(49, makeItem(class_1802.field_8407, "§6Page " + (currentPage + 1) + " / " + (maxPage + 1)));
        if (currentPage > 0) inventory.method_5447(45, makeItem(class_1802.field_8107, "§a§l← Previous"));
        if (currentPage < maxPage) inventory.method_5447(53, makeItem(class_1802.field_8107, "§a§lNext →"));
    }

    private class_1799 makeItem(net.minecraft.class_1792 item, String name) {
        class_1799 stack = new class_1799(item);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(name));
        return stack;
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (actionType != class_1713.field_7790) return;
        if (slotIndex < 0 || slotIndex >= this.field_7761.size()) return;
        if (!(this.field_7761.get(slotIndex) instanceof LockedSlot)) return;

        if (slotIndex == 0) { currentTab = 0; currentPage = 0; resetAndRefresh(); return; }
        if (slotIndex == 1) { currentTab = 1; currentPage = 0; resetAndRefresh(); return; }
        if (slotIndex == 2) { currentTab = 2; currentPage = 0; resetAndRefresh(); return; }
        if (slotIndex == 8) { resetAndRefresh(); return; }
        if (slotIndex == 45 && currentPage > 0) { currentPage--; refreshDisplay(); return; }
        if (slotIndex == 53) { currentPage++; refreshDisplay(); return; }

        if (slotIndex >= COLS && slotIndex < COLS * 5) {
            handleContentClick(slotIndex, button);
        }
    }

    private void resetAndRefresh() {
        manifest = FunctionManager.fetchFunctionManifest();
        localFunctions = FunctionManager.listLocalFunctions();
        refreshDisplay();
    }

    private void handleContentClick(int slotIndex, int button) {
        int contentSlots = COLS * 4;
        int entryIdx = currentPage * contentSlots + (slotIndex - COLS);
        List<FunctionEntry> entries = getCurrentEntries();
        if (entryIdx >= entries.size()) return;

        FunctionEntry entry = entries.get(entryIdx);

        if (player instanceof class_3222 sp) {
            switch (entry.type) {
                case DOWNLOAD -> {
                    FunctionManager.downloadFunction(entry.name, sp.method_64396());
                    scheduleRefresh();
                }
                case LOCAL -> {
                    if (button == 1) {
                        try {
                            Files.deleteIfExists(AliasManager.getFunctionsPath().resolve(entry.name + ".mcfunction"));
                        } catch (Exception ignored) {}
                        scheduleRefresh();
                    } else {
                        net.minecraft.class_2168 source = sp.method_64396();
                        source.method_9211().method_3734().method_44252(
                            source, "/cmd function " + entry.name);
                    }
                }
                case CREATE_EMPTY, CREATE_CMD, CREATE_MOB, CREATE_BUILD -> {
                    String prefix = switch (entry.type) {
                        case CREATE_CMD -> "cmd_";
                        case CREATE_MOB -> "mob_";
                        case CREATE_BUILD -> "build_";
                        default -> "empty_";
                    };
                    String newName = prefix + System.currentTimeMillis() % 100000;
                    try {
                        Path file = AliasManager.getFunctionsPath().resolve(newName + ".mcfunction");
                        Files.createDirectories(file.getParent());
                        Files.writeString(file, "# " + newName + "\n# Created with Command Maker\n");
                    } catch (Exception ignored) {}
                    scheduleRefresh();
                }
            }
        }
    }

    private void scheduleRefresh() {
        new Thread(() -> {
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
            localFunctions = FunctionManager.listLocalFunctions();
            manifest = FunctionManager.fetchFunctionManifest();
            if (currentTab == 0) currentTab = 1;
            currentPage = 0;
            refreshDisplay();
        }).start();
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    private enum EntryType {
        DOWNLOAD, LOCAL, CREATE_EMPTY, CREATE_CMD, CREATE_MOB, CREATE_BUILD
    }

    private static class FunctionEntry {
        final String name;
        final EntryType type;

        FunctionEntry(String name, EntryType type) {
            this.name = name;
            this.type = type;
        }

        class_1799 toItemStack() {
            net.minecraft.class_1792 item = switch (type) {
                case DOWNLOAD -> class_1802.field_8407;
                case LOCAL -> class_1802.field_8529;
                default -> class_1802.field_8674;
            };
            String prefix = switch (type) {
                case DOWNLOAD -> "§a";
                case LOCAL -> "§b";
                default -> "§e";
            };
            class_1799 stack = new class_1799(item);
            stack.method_57379(class_9334.field_49631, class_2561.method_43470(prefix + name));
            return stack;
        }
    }

    private static class LockedSlot extends class_1735 {
        LockedSlot(class_1277 inventory, int index, int x, int y) {
            super(inventory, index, x, y);
        }

        @Override
        public boolean method_7674(class_1657 playerEntity) {
            return false;
        }

        @Override
        public boolean method_7680(class_1799 stack) {
            return false;
        }
    }
}
