package com.example.gui;

import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class FunctionChestScreen extends class_465<FunctionChestHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/gui/container/generic_54.png");

    public FunctionChestScreen(FunctionChestHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2779 = 222;
        this.field_25270 = this.field_2779 - 94;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (this.field_22789 - this.field_2792) / 2;
        int y = (this.field_22790 - this.field_2779) / 2;

        // Draw chest background using fills (avoids API compatibility issues)
        int texW = this.field_2792;
        int texH = this.field_2779;
        context.method_25294(x - 3, y - 3, x + texW + 3, y + texH + 3, 0xFF000000);
        context.method_25294(x, y, x + texW, y + texH, 0xFFC6C6C6);

        // Draw slot backgrounds
        int slotSize = 18;
        for (int i = 0; i < FunctionChestHandler.ROWS; i++) {
            for (int j = 0; j < FunctionChestHandler.COLS; j++) {
                int sx = x + 8 + j * slotSize;
                int sy = y + 18 + i * slotSize;
                context.method_25294(sx, sy, sx + slotSize, sy + slotSize, 0xFF373737);
                context.method_25294(sx + 1, sy + 1, sx + slotSize - 1, sy + slotSize - 1, 0xFF8B8B8B);
            }
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_2380(context, mouseX, mouseY);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        context.method_51439(this.field_22793, class_2561.method_43470("§6§lCommand Maker - Functions"), 8, 6, 0x404040, false);
        context.method_51439(this.field_22793, this.field_29347, 8, this.field_2779 - 94, 0x404040, false);
    }
}
