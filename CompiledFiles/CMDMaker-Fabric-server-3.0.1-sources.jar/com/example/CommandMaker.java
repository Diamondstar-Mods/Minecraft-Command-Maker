package com.example;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.ParseResults;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1657;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_747;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import com.example.gui.ModScreens;
import com.example.gui.FunctionChestHandler;

public class CommandMaker implements ModInitializer {
    public static final String MOD_ID = "cmdmaker";
    public static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        AliasManager.ensureConfigExists();
        AliasManager.loadAliases();
        SyntaxManager.loadSyntaxDefinitions();
        PermissionManager.initialize();
        ModScreens.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            registerCmdCommand(dispatcher);
            registerAddCommand(dispatcher);
            registerAliases(dispatcher);
            registerSetCmdVariable(dispatcher);
            registerDeleteAliasMenu(dispatcher);
            registerSyntaxCommand(dispatcher);
            registerPermissionCommand(dispatcher);
        });

        LOGGER.info("Alias mod initialized!");
    }

    // ---- /cmd (consolidated) ----

    private void registerCmdCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("cmd")
                // add
                .then(class_2170.method_9247("add")
                    .requires(source -> PermissionManager.canManageAliases(source))
                    .then(class_2170.method_9244("alias", StringArgumentType.word())
                        .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String alias = StringArgumentType.getString(ctx, "alias");
                                String command = StringArgumentType.getString(ctx, "command");
                                if (AliasManager.hasAlias(alias)) {
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§cAlias '§f" + alias + "§c' already exists. Use /cmd del " + alias + " first."), false);
                                    return 0;
                                }
                                AliasManager.addAlias(alias, command);
                                registerAlias(dispatcher, alias, command);
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§6Added alias: §f/" + alias + " §7-> §f" + command), false);
                                return 1;
                            })
                        )
                    )
                )
                // del
                .then(class_2170.method_9247("del")
                    .requires(source -> PermissionManager.canManageAliases(source))
                    .then(class_2170.method_9244("alias", StringArgumentType.word())
                        .executes(ctx -> {
                            String alias = StringArgumentType.getString(ctx, "alias");
                            if (AliasManager.removeAlias(alias)) {
                                dispatcher.getRoot().getChildren().removeIf(node -> node.getName().equals(alias));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§6[" + alias + "] was deleted"), false);
                            } else {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§cAlias '§f" + alias + "§c' not found."), false);
                            }
                            return 1;
                        })
                    )
                )
                // reload
                .then(class_2170.method_9247("reload")
                    .requires(source -> PermissionManager.canManageAliases(source))
                    .executes(ctx -> {
                        AliasManager.loadAliases();
                        SyntaxManager.loadSyntaxDefinitions();
                        for (String alias : AliasManager.getAliases().keySet()) {
                            dispatcher.getRoot().getChildren().removeIf(node -> node.getName().equals(alias));
                        }
                        registerAliases(dispatcher);
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§6Reloaded aliases, functions, and syntax definitions."), false);
                        return 1;
                    })
                )
                // function
                .then(class_2170.method_9247("function")
                    .then(class_2170.method_9244("functionName", StringArgumentType.word())
                        .executes(ctx -> {
                            String functionName = StringArgumentType.getString(ctx, "functionName");
                            return FunctionManager.executeFunction(functionName, ctx);
                        })
                    )
                )
                // list
                .then(class_2170.method_9247("list")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        source.method_9226(() -> class_2561.method_43470("Aliases:"), false);
                        for (Map.Entry<String, String> entry : AliasManager.getAliases().entrySet()) {
                            source.method_9226(() -> class_2561.method_43470("  /" + entry.getKey() + " -> " + entry.getValue()), false);
                        }
                        source.method_9226(() -> class_2561.method_43470("Functions:"), false);
                        for (String name : FunctionManager.listLocalFunctions()) {
                            source.method_9226(() -> class_2561.method_43470("  " + name), false);
                        }
                        return 1;
                    })
                )
                // gui
                .then(class_2170.method_9247("gui")
                    .executes(ctx -> {
                        class_1657 player = ctx.getSource().method_44023();
                        if (player != null) {
                            player.method_17355(new class_747(
                                (syncId, inv, p) -> new FunctionChestHandler(syncId, inv, ModScreens.FUNCTION_CHEST),
                                class_2561.method_43470("Command Maker - Functions")
                            ));
                        } else {
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§cThis command can only be used by a player"), false);
                        }
                        return 1;
                    })
                )
                // functions - open function manager GUI
                .then(class_2170.method_9247("functions")
                    .executes(ctx -> {
                        class_1657 player = ctx.getSource().method_44023();
                        if (player != null) {
                            player.method_17355(new class_747(
                                (syncId, inv, p) -> new FunctionChestHandler(syncId, inv, ModScreens.FUNCTION_CHEST),
                                class_2561.method_43470("Command Maker - Functions")
                            ));
                        } else {
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§cThis command can only be used by a player"), false);
                        }
                        return 1;
                    })
                )
                // function subcommands
                .then(class_2170.method_9247("function")
                    .then(class_2170.method_9247("create")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(ctx -> {
                                String name = StringArgumentType.getString(ctx, "name");
                                if (name.contains("..") || name.contains("/") || name.contains("\\")) {
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§c✖ Invalid function name — don't use §f.. / \\ §cin names"), false);
                                    return 0;
                                }
                                try {
                                    Path file = AliasManager.getFunctionsPath().resolve(name + ".mcfunction");
                                    if (Files.exists(file)) {
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("§c✖ Function §f" + name + "§c already exists"), false);
                                        return 0;
                                    }
                                    Files.createDirectories(file.getParent());
                                    String content = "# " + name + "\n# Created with Command Maker\n\n# Add your Minecraft commands below\n# Lines starting with # are comments\n";
                                    Files.writeString(file, content);
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§a✔ Created §f" + name + " §7| Edit: config/CommandMaker/Functions/" + name + ".mcfunction"), false);
                                    return 1;
                                } catch (Exception e) {
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§c✖ Error: §7" + e.getMessage()), false);
                                    return 0;
                                }
                            })
                        )
                    )
                    .then(class_2170.method_9247("delete")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> {
                                for (String name : FunctionManager.listLocalFunctions()) {
                                    builder.suggest(name);
                                }
                                return builder.buildFuture();
                            })
                            .executes(ctx -> {
                                String name = StringArgumentType.getString(ctx, "name");
                                try {
                                    Path file = AliasManager.getFunctionsPath().resolve(name + ".mcfunction");
                                    if (Files.deleteIfExists(file)) {
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("§c🗑 Deleted §f" + name), false);
                                        return 1;
                                    } else {
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("§c✖ Function §f" + name + "§c not found"), false);
                                        return 0;
                                    }
                                } catch (Exception e) {
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§c✖ Error: §7" + e.getMessage()), false);
                                    return 0;
                                }
                            })
                        )
                    )
                )
                // syntax
                .then(class_2170.method_9247("syntax")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        Map<String, CommandSyntax> syntaxes = SyntaxManager.getAllSyntaxes();
                        if (syntaxes.isEmpty()) {
                            source.method_9226(() -> class_2561.method_43470("§cNo custom syntaxes defined."), false);
                            return 0;
                        }
                        source.method_9226(() -> class_2561.method_43470("§6Available Custom Syntaxes:"), false);
                        for (String name : syntaxes.keySet()) {
                            CommandSyntax syntax = syntaxes.get(name);
                            String desc = syntax.getDescription().isEmpty() ? "" : " - " + syntax.getDescription();
                            source.method_9226(() -> class_2561.method_43470("  §f" + name + "§7: §e" + syntax.getPattern() + desc), false);
                        }
                        return 1;
                    })
                )
                // setvar
                .then(class_2170.method_9247("setvar")
                    .then(class_2170.method_9244("key", StringArgumentType.word())
                        .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String key = StringArgumentType.getString(ctx, "key");
                                String value = StringArgumentType.getString(ctx, "value");
                                return VariableManager.setVariable(ctx.getSource(), key, value);
                            })
                        )
                    )
                )
                // donate
                .then(class_2170.method_9247("donate")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        source.method_9226(() -> class_2561.method_43470("§6§l❤️ Support us on Patreon! ❤️"), false);
                        String tellrawCmd = "tellraw " + source.method_9214() + " {\"text\":\"https://commandmakerwiki.lucasgeitgey.com/donate.html\",\"color\":\"blue\",\"underlined\":true,\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://commandmakerwiki.lucasgeitgey.com/donate.html\"}}";
                        var cmdDispatcher = source.method_9211().method_3734().method_9235();
                        var parsed = cmdDispatcher.parse(tellrawCmd, source);
                        cmdDispatcher.execute(parsed);
                        source.method_9226(() -> class_2561.method_43470("§7Click the link above to open in your browser!"), false);
                        return 1;
                    })
                )
                // wiki
                .then(class_2170.method_9247("wiki")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        source.method_9226(() -> class_2561.method_43470("§6§l📚 Command Maker Wiki 📚"), false);
                        String tellrawCmd = "tellraw " + source.method_9214() + " {\"text\":\"https://commandmakerwiki.lucasgeitgey.com\",\"color\":\"blue\",\"underlined\":true,\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://commandmakerwiki.lucasgeitgey.com\"}}";
                        var cmdDispatcher = source.method_9211().method_3734().method_9235();
                        var parsed = cmdDispatcher.parse(tellrawCmd, source);
                        cmdDispatcher.execute(parsed);
                        source.method_9226(() -> class_2561.method_43470("§7Click the link above to open the wiki in your browser!"), false);
                        return 1;
                    })
                )
                // downloadfunction
                .then(class_2170.method_9247("downloadfunction")
                    .then(class_2170.method_9244("function", StringArgumentType.word())
                        .suggests((ctx, builder) -> CompletableFuture.supplyAsync(() -> {
                            Map<String, String> manifest = FunctionManager.fetchFunctionManifest();
                            for (Map.Entry<String, String> entry : manifest.entrySet()) {
                                String name = entry.getKey();
                                String desc = entry.getValue();
                                if (desc != null && !desc.isEmpty()) {
                                    builder.suggest(name, class_2561.method_43470("§7" + desc));
                                } else {
                                    builder.suggest(name);
                                }
                            }
                            return builder.build();
                        }))
                        .executes(ctx -> {
                            String function = StringArgumentType.getString(ctx, "function");
                            FunctionManager.downloadFunction(function, ctx.getSource());
                            return 1;
                        })
                    )
                )
                // listdownloadablefunctions
                .then(class_2170.method_9247("listdownloadablefunctions")
                    .executes(ctx -> {
                        FunctionManager.listDownloadableFunctions(ctx.getSource());
                        return 1;
                    })
                )
        );
    }

    // ---- /addcommand ----

    private void registerAddCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("addcommand")
                .requires(source -> PermissionManager.canUseAddCommand(source))
                .then(class_2170.method_9247("add")
                    .then(class_2170.method_9244("alias", StringArgumentType.word())
                        .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                if (!PermissionManager.canManageAliases(ctx.getSource())) {
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("You don't have permission to add aliases."), false);
                                    return 0;
                                }
                                String alias = StringArgumentType.getString(ctx, "alias");
                                String command = StringArgumentType.getString(ctx, "command");
                                AliasManager.addAlias(alias, command);
                                registerAlias(dispatcher, alias, command);
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Alias /" + alias + " -> " + command + " added."), false);
                                return 1;
                            })
                        )
                    )
                )
                .then(class_2170.method_9247("del")
                    .then(class_2170.method_9244("alias", StringArgumentType.word())
                        .executes(ctx -> {
                            if (!PermissionManager.canManageAliases(ctx.getSource())) {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("You don't have permission to delete aliases."), false);
                                return 0;
                            }
                            String alias = StringArgumentType.getString(ctx, "alias");
                            if (AliasManager.removeAlias(alias)) {
                                dispatcher.getRoot().getChildren().removeIf(node -> node.getName().equals(alias));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Alias /" + alias + " removed."), false);
                            } else {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Alias /" + alias + " not found."), false);
                            }
                            return 1;
                        })
                    )
                )
                .then(class_2170.method_9247("reload")
                    .executes(ctx -> {
                        AliasManager.loadAliases();
                        for (String alias : AliasManager.getAliases().keySet()) {
                            dispatcher.getRoot().getChildren().removeIf(node -> node.getName().equals(alias));
                        }
                        registerAliases(dispatcher);
                        ctx.getSource().method_9226(() -> class_2561.method_43470("Aliases reloaded."), false);
                        return 1;
                    })
                )
        );
    }

    // ---- /setcmdvariable ----

    private void registerSetCmdVariable(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("setcmdvariable")
                .then(class_2170.method_9244("variable", StringArgumentType.word())
                    .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String var = StringArgumentType.getString(ctx, "variable");
                            String value = StringArgumentType.getString(ctx, "value");
                            return VariableManager.setVariable(ctx.getSource(), var, value);
                        })
                    )
                )
        );
    }

    // ---- Alias registration as Brigadier commands ----

    private void registerAliases(CommandDispatcher<class_2168> dispatcher) {
        for (Map.Entry<String, String> entry : AliasManager.getAliases().entrySet()) {
            registerAlias(dispatcher, entry.getKey(), entry.getValue());
        }
    }

    private void registerAlias(CommandDispatcher<class_2168> dispatcher, String alias, String target) {
        dispatcher.getRoot().getChildren().removeIf(node -> node.getName().equals(alias));
        dispatcher.register(
            class_2170.method_9247(alias)
                .executes(ctx -> {
                    class_2168 source = ctx.getSource();
                    if (!PermissionManager.canUseAlias(source, alias)) {
                        source.method_9226(() -> class_2561.method_43470("You don't have permission to use this alias."), false);
                        return 0;
                    }
                    if (target.startsWith("function:")) {
                        return FunctionManager.executeFunction(target.substring("function:".length()), ctx);
                    }
                    String command = VariableManager.substituteVariables(target, ctx);
                    var cmdDispatcher = source.method_9211().method_3734().method_9235();
                    ParseResults<class_2168> parsed = cmdDispatcher.parse(command, source);
                    return cmdDispatcher.execute(parsed);
                })
                .then(class_2170.method_9244("args", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!PermissionManager.canUseAlias(source, alias)) {
                            source.method_9226(() -> class_2561.method_43470("You don't have permission to use this alias."), false);
                            return 0;
                        }
                        if (target.startsWith("function:")) {
                            return FunctionManager.executeFunction(target.substring("function:".length()), ctx);
                        }
                        String args = StringArgumentType.getString(ctx, "args");
                        String full = alias + " " + args;
                        SyntaxManager.SyntaxMatch match = SyntaxManager.matchInput(full);
                        String command;
                        if (match != null) {
                            String substituted = match.syntax.substituteParameters(target, match.parameters);
                            command = VariableManager.substituteVariables(substituted, ctx);
                        } else {
                            command = target + " " + args;
                            command = VariableManager.substituteVariables(command, ctx);
                        }
                        var cmdDispatcher = source.method_9211().method_3734().method_9235();
                        ParseResults<class_2168> parsed = cmdDispatcher.parse(command, source);
                        return cmdDispatcher.execute(parsed);
                    })
                )
        );
    }

    // ---- /deletealias ----

    private void registerDeleteAliasMenu(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("deletealias")
                .executes(ctx -> {
                    class_2168 source = ctx.getSource();
                    Map<String, String> snapshot = AliasManager.getAliases();
                    if (snapshot.isEmpty()) {
                        source.method_9226(() -> class_2561.method_43470("§cNo aliases to delete."), false);
                        return 0;
                    }
                    source.method_9226(() -> class_2561.method_43470("§6Delete Aliases Menu:"), false);
                    final int[] index = {1};
                    for (String alias : snapshot.keySet()) {
                        String cmd = snapshot.get(alias);
                        int idx = index[0];
                        source.method_9226(() -> class_2561.method_43470("  §f[" + idx + "] §6/" + alias + " §7-> §f" + cmd), false);
                        index[0]++;
                    }
                    source.method_9226(() -> class_2561.method_43470("§7Use: §f/cmd del <alias>§7 to delete"), false);
                    return 1;
                })
                .then(class_2170.method_9244("alias", StringArgumentType.word())
                    .executes(ctx -> {
                        String alias = StringArgumentType.getString(ctx, "alias");
                        class_2168 source = ctx.getSource();
                        if (AliasManager.removeAlias(alias)) {
                            dispatcher.getRoot().getChildren().removeIf(node -> node.getName().equals(alias));
                            source.method_9226(() -> class_2561.method_43470("§6[" + alias + "] was deleted"), false);
                        } else {
                            source.method_9226(() -> class_2561.method_43470("§cAlias '§f" + alias + "§c' not found."), false);
                        }
                        return 1;
                    })
                )
        );
    }

    // ---- /syntax ----

    private void registerSyntaxCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("syntax")
                .executes(ctx -> {
                    class_2168 source = ctx.getSource();
                    Map<String, CommandSyntax> syntaxes = SyntaxManager.getAllSyntaxes();
                    if (syntaxes.isEmpty()) {
                        source.method_9226(() -> class_2561.method_43470("§cNo custom syntaxes defined."), false);
                        return 0;
                    }
                    source.method_9226(() -> class_2561.method_43470("§6Available Custom Syntaxes:"), false);
                    for (String name : syntaxes.keySet()) {
                        CommandSyntax syntax = syntaxes.get(name);
                        String desc = syntax.getDescription().isEmpty() ? "" : " - " + syntax.getDescription();
                        source.method_9226(() -> class_2561.method_43470("  §f" + name + "§7: §e" + syntax.getPattern() + desc), false);
                    }
                    return 1;
                })
        );
    }

    // ---- /cmmakerperm ----

    private void registerPermissionCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("cmmakerperm")
                .requires(source -> source.method_9259(4))
                .then(class_2170.method_9247("grant")
                    .then(class_2170.method_9244("player", StringArgumentType.word())
                        .then(class_2170.method_9244("permission", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String playerName = StringArgumentType.getString(ctx, "player");
                                ctx.getSource().method_9211().method_3760().method_14566(playerName);
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§cNote: For full permission management, use LuckPerms or edit permissions.json directly"), false);
                                return 1;
                            })
                        )
                    )
                )
                .then(class_2170.method_9247("revoke")
                    .then(class_2170.method_9244("player", StringArgumentType.word())
                        .then(class_2170.method_9244("permission", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§cNote: For full permission management, use LuckPerms or edit permissions.json directly"), false);
                                return 1;
                            })
                        )
                    )
                )
                .then(class_2170.method_9247("check")
                    .then(class_2170.method_9244("player", StringArgumentType.word())
                        .then(class_2170.method_9244("permission", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§cNote: For full permission checking, use LuckPerms"), false);
                                return 1;
                            })
                        )
                    )
                )
                .then(class_2170.method_9247("reload")
                    .executes(ctx -> {
                        PermissionManager.initialize();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§aPermission config reloaded!"), false);
                        return 1;
                    })
                )
        );
    }
}
