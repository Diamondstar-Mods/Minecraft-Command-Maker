package com.example;

import com.mojang.brigadier.context.CommandContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import net.minecraft.class_2168;

public class VariableManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("cmdmaker");

    private static final Map<UUID, Map<String, String>> playerVariables = new HashMap<>();

    public static String substituteVariables(String command, CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        Map<String, String> vars = new HashMap<>();
        try {
            vars.put("player", source.method_9214());
            vars.put("x", String.valueOf(source.method_9222().field_1352));
            vars.put("y", String.valueOf(source.method_9222().field_1351));
            vars.put("z", String.valueOf(source.method_9222().field_1350));
            UUID uuid = source.method_44023() != null ? source.method_44023().method_5667() : null;
            if (uuid != null && playerVariables.containsKey(uuid)) {
                vars.putAll(playerVariables.get(uuid));
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to resolve built-in variables for command substitution", e);
        }
        for (Map.Entry<String, String> entry : vars.entrySet()) {
            command = command.replace("${" + entry.getKey() + "}", entry.getValue());
        }
        return command;
    }

    public static int setVariable(class_2168 source, String key, String value) {
        UUID uuid;
        try {
            uuid = source.method_44023().method_5667();
        } catch (Exception e) {
            source.method_9226(() -> net.minecraft.class_2561.method_43470("Only players can set variables."), false);
            return 0;
        }
        playerVariables.computeIfAbsent(uuid, k -> new HashMap<>()).put(key, value);
        source.method_9226(() -> net.minecraft.class_2561.method_43470("Set variable ${" + key + "} = " + value), false);
        return 1;
    }
}
