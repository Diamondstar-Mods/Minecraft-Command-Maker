package com.example;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;
import com.example.gui.ModScreens;
import com.example.gui.FunctionChestScreen;

public class CommandMakerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_3929.method_17542(ModScreens.FUNCTION_CHEST, FunctionChestScreen::new);
    }
}
