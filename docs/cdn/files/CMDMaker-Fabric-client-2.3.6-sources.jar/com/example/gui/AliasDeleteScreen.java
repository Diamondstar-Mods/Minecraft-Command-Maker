package com.example.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class AliasDeleteScreen extends class_437 {
	private static final int COLUMNS = 9;
	private static final int SLOT_SIZE = 18;
	private static final int PADDING = 10;

	private final Map<String, String> aliases;
	private final class_437 previousScreen;
	private List<String> aliasNames;
	private int scrollOffset = 0;
	private final int visibleRows = 5;

	public AliasDeleteScreen(Map<String, String> aliases, class_437 previousScreen) {
		super(class_2561.method_43470("Delete Aliases"));
		this.aliases = aliases; // Use reference, not copy
		this.previousScreen = previousScreen;
		this.aliasNames = new ArrayList<>(aliases.keySet());
	}

	@Override
	protected void method_25426() {
		super.method_25426();
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		this.method_25420(context, mouseX, mouseY, delta);
		context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF8B8B8B);

		int titleY = PADDING;
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, titleY, 0xFFFFFF);

		int startX = PADDING;
		int startY = PADDING + 20;
		int endX = this.field_22789 - PADDING;
		int endY = startY + (SLOT_SIZE * visibleRows);

		context.method_25294(startX - 2, startY - 2, endX + 2, endY + 2, 0xFF000000);
		context.method_25294(startX, startY, endX, endY, 0xFF3F3F3F);

		int slotIndex = scrollOffset * COLUMNS;

		for (int row = 0; row < visibleRows; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (slotIndex >= aliasNames.size()) break;

				int x = startX + col * SLOT_SIZE;
				int y = startY + row * SLOT_SIZE;

				String aliasName = aliasNames.get(slotIndex);
				String command = aliases.get(aliasName);

				drawStoneBlock(context, x, y, aliasName, command, mouseX, mouseY);
				slotIndex++;
			}
		}

		int instructY = endY + PADDING;
		context.method_27535(this.field_22793, class_2561.method_43470("Click a block to delete the alias"), startX, instructY, 0xFFFFFF);
		context.method_27535(this.field_22793, class_2561.method_43470("Press ESC to go back"), startX, instructY + 12, 0xFFAAAAAA);
	}

	private void drawStoneBlock(class_332 context, int x, int y, String alias, String command, int mouseX, int mouseY) {
		boolean isHovered = mouseX >= x && mouseX < x + SLOT_SIZE && mouseY >= y && mouseY < y + SLOT_SIZE;

		int bgColor = isHovered ? 0xFF5F5F5F : 0xFF4F4F4F;
		context.method_25294(x, y, x + SLOT_SIZE, y + SLOT_SIZE, bgColor);
		context.method_25294(x + 2, y + 2, x + SLOT_SIZE - 2, y + SLOT_SIZE - 2, 0xFF8B8B8B);

		context.method_25294(x, y, x + SLOT_SIZE, y + 1, 0xFFFFFFFF);
		context.method_25294(x, y, x + 1, y + SLOT_SIZE, 0xFFFFFFFF);
		context.method_25294(x + SLOT_SIZE - 1, y, x + SLOT_SIZE, y + SLOT_SIZE, 0xFF333333);
		context.method_25294(x, y + SLOT_SIZE - 1, x + SLOT_SIZE, y + SLOT_SIZE, 0xFF333333);

		if (isHovered) {
			List<class_2561> tooltip = new ArrayList<>();
			tooltip.add(class_2561.method_43470("§6/" + alias));
			tooltip.add(class_2561.method_43470("§7Command: " + command));
			context.method_51434(this.field_22793, tooltip, mouseX + 5, mouseY + 5);
		}
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		int totalSlots = aliasNames.size();
		int maxScroll = Math.max(0, (totalSlots + COLUMNS - 1) / COLUMNS - visibleRows);

		scrollOffset -= (int) verticalAmount;
		if (scrollOffset < 0) scrollOffset = 0;
		if (scrollOffset > maxScroll) scrollOffset = maxScroll;

		return true;
	}

	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button != 0) return false;

		int startX = PADDING;
		int startY = PADDING + 20;

		int slotIndex = scrollOffset * COLUMNS;
		for (int row = 0; row < visibleRows; row++) {
			for (int col = 0; col < COLUMNS; col++) {
				if (slotIndex >= aliasNames.size()) break;

				int x = startX + col * SLOT_SIZE;
				int y = startY + row * SLOT_SIZE;

				if (mouseX >= x && mouseX < x + SLOT_SIZE && mouseY >= y && mouseY < y + SLOT_SIZE) {
					String aliasToDelete = aliasNames.get(slotIndex);
					deleteAlias(aliasToDelete);
					return true;
				}
				slotIndex++;
			}
		}

		return false;
	}

	private void deleteAlias(String alias) {
		if (this.field_22787 != null && this.field_22787.field_1724 != null) {
			this.field_22787.field_1724.field_3944.method_45729("/cmd del " + alias);
		}

		aliases.remove(alias);
		aliasNames.remove(alias);
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(previousScreen);
	}

	@Override
	public boolean method_25422() {
		return true;
	}
}